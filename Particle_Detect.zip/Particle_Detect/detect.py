import numpy as np
from Data import Data
from PIL import Image
from read import Read_Image
from Seg import Kmeans_Seg,MOG2
from Locate import locate,write_single_img_json
import os
import json
import cv2
Left_Image_Path='C:/Users/Claudius/WorkingSpace/Article1/0722experiment2/51/BMP192.168.8.51-20240707-072633'
Right_Image_Path='C:/Users/Claudius/WorkingSpace/Article1/0722experiment2/52/BMP192.168.8.52-20240707-072635'
Kmeans=Kmeans_Seg()
Back_SubSegLeft=MOG2(Left_Image_Path)
Back_SubSegLeft.pretrain(1000,1999)
Back_SubSegRight=MOG2(Right_Image_Path)
Back_SubSegRight.pretrain(1000,1999)
Left_sight=[]
Right_sight=[]

    
for val in range(2000,2100):
    left=Back_SubSegLeft.MOG2_Seg(val,False)
    right=Back_SubSegRight.MOG2_Seg(val,False)
    Image_Info_Left,Radius_Info_Left,Img_Path_Info_Left=locate(left,Left_Image_Path,Kmeans,Back_SubSegLeft)
    Image_Info_Right,Radius_Info_Right,Img_Path_Info_Right=locate(right,Right_Image_Path,Kmeans,Back_SubSegRight)
    Left_sight.append([Radius_Info_Left,Img_Path_Info_Left])
    Right_sight.append([Radius_Info_Right,Img_Path_Info_Right])
Left_Sight_Data_JSON='Particle_info_left.json'
Right_Sight_Data_JSON='Particle_info_right.json'
with open(Left_Sight_Data_JSON, "r+") as file:  # 以读写模式打开
     file.truncate(0)  # 清空文件内容
with open(Right_Sight_Data_JSON, "r+") as file:
    file.truncate(0)
for i in range(len(Left_sight)):
    write_single_img_json(Left_Sight_Data_JSON,Left_sight[i][0],Left_sight[i][1])
    write_single_img_json(Right_Sight_Data_JSON,Right_sight[i][0],Right_sight[i][1])